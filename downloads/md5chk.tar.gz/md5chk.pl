#!/usr/bin/perl
# md5chk.pl
# Utility for checking MD5s

use strict;

my $count = @ARGV;

my $file = $ARGV[0];
my $md5  = $ARGV[1];

if ($md5 eq undef) {
	$md5 = find_md5($file);
}

my $md5text = crop(get_md5text($md5));

if ($md5text eq undef) {
	$md5text = `kdialog --title "MD5 Checker" --icon package_utilities --inputbox "Please enter the MD5 string here:"`;
	unless ($? == 0) { exit; }
	chomp($md5text);
}

my $md5sum = crop(`md5sum $file`);

if ($md5text eq undef) {
	`kdialog --title "MD5 Checker" --icon package_utilities --msgbox "$md5sum"`;
} elsif ($md5sum eq $md5text) {
	`kdialog --title "MD5 Checker" --icon package_utilities --msgbox "MD5 matches perfectly"`;
} else {
	`kdialog --title "MD5 Checker" --icon package_utilities --error "MD5 Differs $md5sum $md5text"`;
}

exit;

sub crop {
	my $text = $_[0];
	chomp($text);
	my ($md5) = split(/\ /, $text);
	return $md5;
}

sub croak {
	my $msg;

	`kdialog --title "MD5 Checker" --icon package_utilities --error "$msg"`;
	exit;
}

sub get_md5text {
	my $file = $_[0];

	unless (-e $file) {
		return undef;
	}

	open(MD5, $file) || croak("Cannot read $file: $!");
	$md5text = <MD5>;
	chomp($md5text);
	close(MD5) || croak("Cannot close $file: $!");

	if ($md5text eq undef) {
		croak("Cannot find md5sum in $file");
	}

	return $md5text;
}

sub find_md5 {
	my $file = $_[0];

	my $name = $file;
	$name =~ s/\..*$//;
	$name .= '.md5';

	if (-e $name) {
		return $name;
	} else {
		return undef;
	}
}
